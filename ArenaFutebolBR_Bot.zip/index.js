import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';
import { Client, GatewayIntentBits, Events, REST, Routes, SlashCommandBuilder, Collection, EmbedBuilder } from 'discord.js';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.commands = new Collection();

const palpitesPath = path.resolve('./palpites.json');
const resultadosPath = path.resolve('./resultados.json');

let palpites = fs.existsSync(palpitesPath) ? JSON.parse(fs.readFileSync(palpitesPath, 'utf8')) : {};
let resultados = fs.existsSync(resultadosPath) ? JSON.parse(fs.readFileSync(resultadosPath, 'utf8')) : {};

function salvarPalpites() {
  fs.writeFileSync(palpitesPath, JSON.stringify(palpites, null, 2));
}
function salvarResultados() {
  fs.writeFileSync(resultadosPath, JSON.stringify(resultados, null, 2));
}

const commands = [
  new SlashCommandBuilder().setName('jogos-hoje').setDescription('Veja os jogos de hoje no futebol mundial'),
  new SlashCommandBuilder().setName('serie-a').setDescription('Jogos da Série A do Brasileirão'),
  new SlashCommandBuilder().setName('palpite')
    .setDescription('Dê seu palpite para um jogo')
    .addStringOption(opt => opt.setName('jogo').setDescription('Ex: Flamengo x Palmeiras').setRequired(true))
    .addStringOption(opt => opt.setName('placar').setDescription('Ex: 2x1').setRequired(true)),
  new SlashCommandBuilder().setName('editar-palpite')
    .setDescription('Edite seu palpite')
    .addStringOption(opt => opt.setName('jogo').setDescription('Jogo que você já deu palpite').setRequired(true))
    .addStringOption(opt => opt.setName('novo_placar').setDescription('Novo placar').setRequired(true)),
  new SlashCommandBuilder().setName('meus-palpites').setDescription('Veja seus palpites registrados'),
  new SlashCommandBuilder().setName('atualizar-resultados').setDescription('Atualiza os resultados para conferência de palpites'),
  new SlashCommandBuilder().setName('ranking').setDescription('Veja o ranking dos palpites')
].map(cmd => cmd.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

client.once(Events.ClientReady, () => {
  console.log(`✅ ArenaFutebolBR está online como ${client.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const { commandName, options } = interaction;

  if (commandName === 'jogos-hoje') {
    try {
      const res = await fetch('https://api.api-futebol.com.br/v1/partidas', {
        headers: { Authorization: `Bearer ${process.env.API_KEY}` }
      });
      const data = await res.json();

      if (!data || !data.length) return interaction.reply('⚠️ Nenhum jogo encontrado para hoje.');

      const jogos = data.slice(0, 5).map(j => `⚽ **${j.campeonato.nome}**\n🟢 ${j.time_mandante.nome} x ${j.time_visitante.nome}`).join('\n\n');
      interaction.reply({ embeds: [new EmbedBuilder().setTitle('📅 Jogos de Hoje').setDescription(jogos).setColor('Blue')] });
    } catch (err) {
      console.error(err);
      interaction.reply('❌ Erro ao buscar jogos.');
    }
  }

  if (commandName === 'serie-a') {
    interaction.reply('🇧🇷 Em breve: dados da Série A com horários e transmissão.');
  }

  if (commandName === 'palpite') {
    const jogo = options.getString('jogo');
    const placar = options.getString('placar');
    const userId = interaction.user.id;
    const nome = interaction.user.username;

    if (!palpites[jogo]) palpites[jogo] = [];
    const jaExiste = palpites[jogo].some(p => p.userId === userId);
    if (jaExiste) return interaction.reply({ content: '⚠️ Você já enviou um palpite para esse jogo. Use `/editar-palpite`.', ephemeral: true });

    palpites[jogo].push({ userId, nome, placar });
    salvarPalpites();

    interaction.reply({
      embeds: [new EmbedBuilder()
        .setTitle('✅ Palpite Registrado')
        .setDescription(`**${jogo}**\n📊 **${placar}**`)
        .setFooter({ text: `Enviado por ${nome}` })
        .setColor('Green')
        .setTimestamp()]
    });
  }

  if (commandName === 'editar-palpite') {
    const jogo = options.getString('jogo');
    const novoPlacar = options.getString('novo_placar');
    const userId = interaction.user.id;

    if (!palpites[jogo]) return interaction.reply('⚠️ Nenhum palpite encontrado para esse jogo.');

    const palpite = palpites[jogo].find(p => p.userId === userId);
    if (!palpite) return interaction.reply('⚠️ Você ainda não deu palpite para esse jogo.');

    palpite.placar = novoPlacar;
    salvarPalpites();

    interaction.reply(`✏️ Palpite atualizado para **${jogo}**: **${novoPlacar}**`);
  }

  if (commandName === 'meus-palpites') {
    const userId = interaction.user.id;
    const lista = [];

    for (const jogo in palpites) {
      palpites[jogo].forEach(p => {
        if (p.userId === userId) lista.push(`• ${jogo}: **${p.placar}**`);
      });
    }

    if (!lista.length) return interaction.reply('📭 Você ainda não deu nenhum palpite.');
    interaction.reply(`📋 **Seus palpites:**\n${lista.join('\n')}`);
  }

  if (commandName === 'atualizar-resultados') {
    resultados = {
      'Flamengo x Palmeiras': '2x1',
      'São Paulo x Santos': '1x1'
    };
    salvarResultados();
    interaction.reply('✅ Resultados atualizados!');
  }

  if (commandName === 'ranking') {
    const pontuacao = {};

    for (const jogo in palpites) {
      const resultado = resultados[jogo];
      if (!resultado) continue;

      palpites[jogo].forEach(p => {
        if (p.placar === resultado) {
          pontuacao[p.nome] = (pontuacao[p.nome] || 0) + 3;
        }
      });
    }

    const ranking = Object.entries(pontuacao)
      .sort((a, b) => b[1] - a[1])
      .map(([nome, pontos], idx) => {
        const emoji = idx === 0 ? '👑' : idx === 1 ? '🤴' : '🍼';
        return `${emoji} **${nome}** - ${pontos} pts`;
      });

    if (!ranking.length) return interaction.reply('📊 Nenhum palpite acertado ainda.');
    interaction.reply({ embeds: [new EmbedBuilder().setTitle('🏆 Ranking dos Palpites').setDescription(ranking.join('\n')).setColor('Gold')] });
  }
});

(async () => {
  try {
    console.log('🔄 Registrando comandos...');
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commands }
    );
    client.login(process.env.DISCORD_TOKEN);
  } catch (err) {
    console.error('Erro ao registrar comandos:', err);
  }
})();