# Política de Privacidade - ArenaFutebolBR

Este bot não coleta, armazena ou compartilha informações pessoais dos usuários. Toda interação é temporária e usada apenas para mostrar dados esportivos.