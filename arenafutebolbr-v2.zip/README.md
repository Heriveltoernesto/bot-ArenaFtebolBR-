# ArenaFutebolBR

🤖 Bot de Discord com resultados ao vivo, sistema de palpites e integração com YouTube e rádios esportivas.

## Comandos disponíveis

- `/jogos-hoje` → todos os jogos do dia
- `/serie-a` → Brasileirão Série A
- `/palpite [jogo] [placar]` → envie seu palpite!

## Como rodar

1. Clone ou envie para Replit
2. Crie um `.env` com suas chaves (veja `.env.example`)
3. Rode `npm install` e `npm start`