# Termos de Serviço - ArenaFutebolBR

O uso deste bot é gratuito. O usuário concorda em utilizar de forma ética e respeitar as regras do Discord. Não há garantias de funcionamento contínuo.